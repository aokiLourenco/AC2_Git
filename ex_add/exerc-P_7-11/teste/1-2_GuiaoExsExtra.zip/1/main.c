#include <detpic32.h>

static unsigned int key = 0;
volatile static int displayValue = 0, displayStatus = 'D';
static unsigned int displayFlag = 0;

void delay(unsigned int ms) {
        resetCoreTimer();
        while(readCoreTimer() < 20000*ms);
}

void init() {
        TRISE = TRISE & 0xFFF0;
        LATE = LATE & 0xFFF0;
        TRISB = TRISB & 0x80FF;         // 1000 0000 1111 1111
        TRISDbits.TRISD5 = 0;
        TRISDbits.TRISD6 = 0;
        LATDbits.LATD5 = 0;
        LATDbits.LATD6 = 0;
      
        T2CONbits.TCKPS = 2;    // K = 4
        PR2 = 49999;
        TMR2 = 0;
        T2CONbits.TON = 1;
        IPC2bits.T2IP = 2; // prioridade da interrupção (1 a 6)
        IFS0bits.T2IF = 0; // limpar pedido de interrupção do temporizador x
        IEC0bits.T2IE = 1; // ativar pedidos de interrupção do temporizador x

}

void send2displays(unsigned int value, char status) {
        displayValue = value;
        displayStatus = status;
        static unsigned int display7Scodes[] = {0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x6F, 0x77, 0x7C, 0x39, 0x5E, 0x79, 0x71};
        
        if(status == 'D') {
                LATDbits.LATD6 = 0;
                LATDbits.LATD5 = 0;
                return;
        }

        unsigned int digit_low = value & 0x0F;
        unsigned int digit_high = value >> 4;
        if(displayFlag == 0) {
                LATDbits.LATD6 = 1;             // Ativar o Segmento 1
                LATDbits.LATD5 = 0;
                LATB = (LATB & 0x80FF) | (display7Scodes[digit_high] << 8);
        } else {
                LATDbits.LATD6 = 0;             // Ativar o Segmento 0
                LATDbits.LATD5 = 1;
                LATB = (LATB & 0x80FF) | (display7Scodes[digit_low] << 8);
        }
        displayFlag = !displayFlag;
}

void _int_(8) isr_T2(void) {
        send2displays(displayValue,displayStatus);
        IFS0bits.T2IF = 0;      // limpar o pedido de interrupção
}

void configLEDs(unsigned int key) {
        switch(key) {
                case '0':
                        send2displays(0x00,'A');
                        LATE = (LATE & 0xFFF0) | 0x0001;
                        break;
                case '1':
                        send2displays(0x01,'A');
                        LATE = (LATE & 0xFFF0) | 0x0002;
                        break;
                case '2':
                        send2displays(0x02,'A');
                        LATE = (LATE & 0xFFF0) | 0x0004;
                        break;
                case '3':
                        send2displays(0x03,'A');
                        LATE = (LATE & 0xFFF0) | 0x0008;
                        break;
                default:send2displays(0xFF,'A');
                        LATE = (LATE & 0xFFF0) | 0x000F;
                        delay(1000);
                        LATE = (LATE & 0xFFF0);
                        send2displays(0xFF,'D');
                        break;
        }
}

int main(void) {
        init();
        EnableInterrupts();
        while(1) {  
                key = inkey();
                if(key != '\0') {
                        configLEDs(key);
                }
        }
        return 0;
}
