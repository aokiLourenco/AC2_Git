#include <detpic32.h>
#define BAUDRATE 57600

// Escreva um programa que leia, à frequência de 1.5 Hz, o valor dos 4 bits dos portos RB3 a RB0 e
// que guarde esse valor num buffer circular com 16 posições (quando o buffer ficar cheio deve ser
// descartado o valor mais antigo). Para gerar esta temporização deve usar o Core Timer.
// Configure a UART2 com os parâmetros de comunicação 57600 bps, 8 data bits, paridade ímpar, 1
// stop bit, e escreva as funções de transmissão de um carater e de transmissão de uma string, por
// polling. Acrescente ainda o código necessário para processar a receção de um caracter por
// interrupção.
// Quando for recebido o carater ‘D’ deve ser enviado para o PC o número de valores armazenados
// no buffer circular, seguido desses valores, enviados por ordem cronológica de ocorrência.
// Adicionalmente, o número de valores do buffer deve ser reposto a zero.
// Sugestão: transforme o valor armazenado numa dada posição do buffer circular numa string
// binária e use a função de envio de uma string para fazer a transmissão do valor para o PC (por
// exemplo: #elem: 5 – 1001, 1001, 0000, 0011, 1010).

void delay(unsigned int Hz) {
        resetCoreTimer();
        while(readCoreTimer() < PBCLK*10/Hz);
}

void init() {
        // Configure UART2 (1200, N, 8, 1):
        U2BRG = (PBCLK+(8*BAUDRATE))/(16*BAUDRATE)-1;
        U2MODEbits.BRGH = 0;
        U2MODEbits.PDSEL = 1;   // Impar
        U2MODEbits.STSEL = 0;
        U2STAbits.UTXEN = 1;
        U2STAbits.URXEN = 0;
        U2MODEbits.ON = 1;

        TRISB = TRISB | 0x000F;
}

void putc(char byte1) {
        while(U2STAbits.UTXBF == 1);    // wait while UTXBF == 1
        U2TXREG = byte1;                 // Copy byte2send to the UxTXREG register
}

char getc(void)
{
        while(U2STAbits.URXDA == 0);    // Wait while URXDA == 0
        return U2RXREG;
}

int main(void) {
        init();
        while(1) {
                delay(15);              // 1.5Hz
        }
        return 0;
}